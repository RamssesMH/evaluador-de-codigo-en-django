#!/usr/bin/env bash

echo "¿Cuál es tu nombre?"
read nombre
echo "¿Cuál es tu edad?"
read edad
echo "¿Qué estudias?"
read estudios

echo "Hola $nombre, tienes $edad y estudias $estudios"
