#!/usr/bin/env bash

while [ 1 -eq 1 ]; do
    echo "Entrando a la impresión"
    echo "nada" >> /tmp/salida.txt
    echo "Me voy a dormir"
    sleep 60
    echo "Ya desperté"
done
