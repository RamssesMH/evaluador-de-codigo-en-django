#!/usr/bin/env bash

archivo_a_respaldar="$1"
directorio_salida="$2"

fecha=$(date +%Y%m%d)
nombre_sin_ruta=$(basename "$archivo_a_respaldar")

salida_completa="$directorio_salida/${nombre_sin_ruta}$fecha"

echo $USER > "$salida_completa"
cat "$archivo_a_respaldar" >> "$salida_completa"
