#! /bin/bash
echo 'salida final' > /home/ramsses/psegura/proyectoPrograSegura/validador_de_ej_hola/ej2-imprime-archivo/nombrearchivo.txt